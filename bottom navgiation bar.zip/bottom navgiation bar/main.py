import flet
from flet import *

def main(page) -> None:
    page.window_width = 400
    page.padding = 0
    page.spacing = 0
    page.bgcolor = "blue"
    # create abullet for right and left position
    bullet = Container(

        # right and leftset offest for bullet
        offset=transform.Offset(0,0),
        # animation for set
        animate_offset= animation.Animation(200,"easeIn"),

        shape = BoxShape.CIRCLE,
        bgcolor="blue",
        height = 90,
        left = 1,
        right = 1,
        margin = margin.only(
            top= page.window_height-80
        ),
        content = Icon(name="bookmark", size = 40)
    )

    def changeposition(e):
        if e.control.data == "home":
            bullet.offset = transform.Offset(-0.4,0)
            # change icon
            bullet.content = Icon(name="home", size = 40)
            page.bgcolor = "green"
            bullet.bgcolor="black"
        if e.control.data == "bookmark":
            bullet.offset = transform.Offset(0.0,0)
            # change icon
            bullet.content = Icon(name="home", size = 40)
            page.bgcolor = "blue"
            bullet.bgcolor="black"
        if e.control.data == "person":
            bullet.offset = transform.Offset(0.4,0)
            # change icon
            bullet.content = Icon(name="home", size = 40)
            page.bgcolor = "white"
            bullet.bgcolor="black"

        page.update()





    

    # now create nav in bottom of your app

    nav = Container(
        bgcolor = "white",
        width = page.window_width,

        # add to bottom
        margin = margin.only(
            top = page.window_height-60
        ),
        border_radius= 30,
        content = Row([
            IconButton(icon="home",
                       icon_size=40,
                       data = "home",
                       on_click=changeposition
                       ),
                       IconButton(icon="bookmark",
                       icon_size=40,
                        data = "bookmark",
                       on_click=changeposition
                       ),
                       IconButton(icon="person",
                       icon_size=40,
                        data = "person",
                       on_click=changeposition
                       ),
        ], alignment="spaceBetween")
    )


    page.add(
        Stack([
            nav,
            bullet
        ])
    )
flet.app(target=main)
from flet import *
def main(page: Page):

    # change a blur with slider
    page.bgcolor = "blue"

    def blue_update(e):
        result_con.shadow[0].blur_radius = e.control.value
        result_con.shadow[1].blur_radius = e.control.value
        page.update()
        print(result_con.shadow[1].blur_radius)


    setting_con = Container(
        padding=10,
        width=page.window_width,
        height = 300,
        bgcolor="white",
        content=Column([
            Row([
                Text("Blur", color="black"),
                Slider(min=10,max=100,
                       label = "change blur",
                       on_change = blue_update,
                       )
            ])
        ])
    )



    result_con = Container(
        # make a neuro design
        margin = 30,
        width = 400,
        height = 300,
        border_radius=40,
        bgcolor = "blue",
        alignment=alignment.center,
        content=Text("Coder", size=30, color="white"),
        shadow=[
            BoxShadow(
                offset=Offset(34,34),
                blur_radius=54,
                color="#a4a6af",
                blur_style=ShadowBlurStyle.NORMAL
            ),
            BoxShadow(
                offset=Offset(-18,4),
                blur_radius=54,
                color="#dde1ec",
                blur_style=ShadowBlurStyle.NORMAL
            )
        ]
    )
    page.add(
        Column([
            result_con,
            Container(height=30),
            setting_con
        ])
    )
app(target=main, view=AppView.FLET_APP)
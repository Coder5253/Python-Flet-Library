import flet as ft


#Define a Link style ....
link_style = {
    "height" : 50,
    "focused_border_color" : "#F4CE14",
    "border_radius": 5,
    "cursor_color": "while",
    "content_padding": 10,
    "border_width": 1.5,
    "text_size": 14,
    "label_style": ft.TextStyle(color="#F4CE14")
}

#Define a Link class

class Link(ft.TextField):
    def __init__(self, label : str, value: str, page: ft.Page) -> None:
        super().__init__(
            value= value,
            read_only= True,
            label= label,
            on_focus= None,
            **link_style
        )


#Define a Profile Page....

class ProfilePage(ft.View):
    def __init__(self , page : ft.Page):
        super().__init__(route="/profile", padding= 20),
        self.page = page
        self.controls = [
            ft.SafeArea(
                expand=True,
                content=ft.Column(
                    horizontal_alignment="center",
                    controls=[
                        ft.Divider(height=20 , color="transparent"),
                        ft.Container(
                            bgcolor="white10",
                            width=128,
                            height=128,
                            shape= ft.BoxShape("circle"),
                            #Define image for Profile picture

                            image_src="/profile.png",
                            image_fit="cover",
                            shadow=ft.BoxShadow(
                                spread_radius= 6,
                                blur_radius=20,
                                color=ft.colors.with_opacity(0.71, "black"),
                            ),
                        ),
                        ft.Divider(height=10, color="transparent"),
                        ft.Text("Coder", size=32),

                        ft.Text(
                            "PYTHON PROGRAMER | UI/UX DESIGNER",
                            width="w400",
                            text_align="center"
                        ),
                        ft.Divider(height=50, color="transparent"),
                        ft.Column(
                            spacing=20,
                            controls=(

                                #insert link item....


                                Link("Name", "coder", self.page),

                                Link("Youtube", "@Coder", self.page),
                            )
                        )
                    ]
                )
            )
        ]
#Landing page....

class LandingPage(ft.View):
    def __init__(self, page:ft.Page) -> None:
        super().__init__(route="/Landing", padding=60)

        self.page = page

        #Lock Icon

        self.lock = ft.Icon(
            name="Lock" , scale=ft.Scale(4)
        )

        #Define a button to route to profile

        self.button = ft.Container(
            border_radius=5,
            expand=True,
            bgcolor="#F4CE14",
            content=ft.Text("Coder", color="black", size=18),
            padding=ft.padding.only(left=25, right=25, top=10, bottom=10),
            alignment=ft.alignment.center,
            on_click=None
        )

        #Define the list of control to view

        self.controls = [
            ft.SafeArea(
                expand=True,
                content=ft.Column(
                    alignment="spaceBetween",
                    controls=[
                        ft.Column(
                            controls=[
                                ft.Divider(height=120,
                                           color="transparent"),
                                           self.lock,
                                           ft.Divider(height=70, color= "transparent"),
                                           ft.Text(
                                               "Subscribe to my Youtube Channel",
                                               size=18,
                                               text_align="center",
                                           )
                            ],
                            horizontal_alignment="center"
                        ),
                        ft.Row(
                            controls=[self.button],
                            alignment="center"
                        )
                    ]
                )
            )
        ]





def main(page: ft.Page) -> None: 
    #Define page related settings

    page.theme_mode = ft.ThemeMode.DARK

    #Define a Method to hendal a page routing

    def router(route) -> None:
        page.views.clear()

        if page.route == '/landing':
            landing = LandingPage(page)
            page.views.append(landing)


        if page.route == "/profile":
            profile = ProfilePage(page)
            page.views.append(profile)
    page.update()

    page.on_route_change = router
    page.go("/profile")
ft.app(target=main, assets_dir="assets")